//
//  DashboardViewModel.swift
//  FlowCoordinatorEx
//
//  Created by FSSDeveloper on 21/11/24.
//

import Foundation


protocol DashboardViewModelProtocol {
//    func login(username: String, password: String)
}

class DashboardViewModel: DashboardViewModelProtocol {
    
//    private let coordinator: LoginCoordinatorProtocol
//
//    init(coordinator: LoginCoordinatorProtocol) {
//        self.coordinator = coordinator
//    }
//
}
