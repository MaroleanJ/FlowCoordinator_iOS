//
//  OtpViewController.swift
//  FlowCoordinatorEx
//
//  Created by FSSDeveloper on 21/11/24.
//

import UIKit


class OtpViewController : UIViewController {
    var viewModel: OtpViewModel!

    override func viewDidLoad() {
           super.viewDidLoad()
       }
    
    @IBAction func submitOTP(_ sender: UIButton) {
    }
    
    
}
